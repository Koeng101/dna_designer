import barcode

print(barcode.barcode())
