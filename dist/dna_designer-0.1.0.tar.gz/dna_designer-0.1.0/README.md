# dna_designer

This is the DNA designer package, made by Keoni Gandall originally to help design DNA for the FreeGenes project.

# Notes for koeng
python3 setup.py sdist bdist_wheel
twine upload dist/*
